# Let me Script You: Sniffer Lite v4.0

**Author:** Perisa Reljic `[ ▽ Ш ]`  
**Environment:** Linux / Python 3 (Standard Library only, optional `dig` & `nmap`)

---

## Overview

**Sniffer Lite v4.0** is a lightweight, standalone Python CLI diagnostic and reconnaissance tool for Linux terminals. Built strictly on Python 3's standard library (`socket`, `ssl`, `urllib`, `subprocess`, `concurrent.futures`, `json`), it runs immediately out of the box with zero external Python dependencies while supporting optional system integrations like `dig`/`host` and `nmap`.

## Features

* **Multi-Threaded TCP Port Scanner:** Scans the default 17 key service ports, the first 1,000 ports (`1k` / `1-1000`), or any custom port list/range with lightweight banner grabbing and configurable threads (`--threads`) and timeout (`--timeout`).
* **TLS/SSL Certificate Inspection:** Reads protocol version, cipher suite, certificate CN, issuer organization, Subject Alternative Names (SAN), and validity dates.
* **HTTP Probe, Stack & Security Headers Audit:** Inspects status codes, final redirect URLs, web server signatures, basic stack detection (WordPress, WooCommerce, Plesk, Cloudflare), allowed HTTP methods (`OPTIONS`), cookie security flags (`HttpOnly`, `Secure`, `SameSite`), and categorizes security headers into `CORE` and `OPTIONAL`.
* **DNS Lookup (`--dns`):** Resolves `A` (IPv4) and `AAAA` (IPv6) records, plus `NS`, `MX`, and `TXT` records via `dig` or `host`.
* **Subdomain & Endpoint Recon (`--recon`):** Checks common subdomains (`www`, `mail`, `webmail`, `ftp`, `plesk`, `cpanel`, `dev`, `staging`, `api`, `admin`, etc.) and common web/WordPress endpoints (`/robots.txt`, `/sitemap.xml`, `/wp-login.php`, `/xmlrpc.php`, `/readme.html`, `/wp-json/`, `/.well-known/security.txt`).
* **Optional Nmap Integration (`--nmap`, `--nmap-deep`):** Wraps system `nmap` for service version detection (`-sV`) and HTTP/SSL NSE scripts.
* **Report Export & Diff Comparison (`--save`, `--json`, `--diff`):** Saves human-readable `.txt` and structured `.json` reports, and compares new scans against previous JSON snapshots to track changes.
* **Interactive Menu (`--menu`):** Launch with no arguments or `--menu` for a guided numbered interface.

## Quick Start

Make the script executable:

```bash
chmod +x sniffer_liteV4.0.py